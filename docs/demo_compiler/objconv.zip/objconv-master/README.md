This repo is a git mirror of http://www.agner.org/optimize/objconv.zip by Agner Fog

## Building
You can build objconv with the following command (sorry no Makefile):

    g++ -o objconv -O2 src/*.cpp

## License
It is, as mentioned in the source code, Copyright 2006-2008 GNU General Public License http://www.gnu.org/licenses